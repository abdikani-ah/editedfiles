<div class="wrapper wrapper-content">
	<div class="middle-box text-center animated fadeInRightBig">
		<h3 class="font-bold"><?php __('plugin_base_access_denied_title'); ?></h3>
		<div class="error-desc">
			<?php __('plugin_base_access_denied_desc'); ?>
		</div>
	</div>
</div>