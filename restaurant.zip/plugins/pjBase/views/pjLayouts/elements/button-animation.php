<?php $logo_path = PJ_INSTALL_URL . $controller->getConstant('pjBase', 'PLUGIN_IMG_PATH'); ?>
<strong class="phpjabbers-loader ladda-spinner">
    <span class="load-1"><img src="<?php echo $logo_path;?>phpjabbers-logo-1,3-4.png" alt=""></span>
    <span class="load-2"><img src="<?php echo $logo_path;?>phpjabbers-logo-2-4.png" alt=""></span>
    <span class="load-3"><img src="<?php echo $logo_path;?>phpjabbers-logo-1,3-4.png" alt=""></span>
    <span class="load-4"><img src="<?php echo $logo_path;?>phpjabbers-logo-4-4.png" alt=""></span>
</strong>