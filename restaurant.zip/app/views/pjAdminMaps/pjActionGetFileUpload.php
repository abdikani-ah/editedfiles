<div class="form-group">
    <label class="col-sm-2 control-label"><?php __('lblFile');?></label>

    <div class="col-sm-6">
        <div class="fileinput fileinput-new" data-provides="fileinput">
            <span class="btn btn-primary btn-outline btn-file"><span class="fileinput-new"><i class="fa fa-upload m-r-xs"></i><?php __('plugin_base_locale_select_file');?></span>
            <span class="fileinput-exists"><i class="fa fa-upload m-r-xs"></i><?php __('plugin_base_locale_change_file');?></span><input name="path" type="file"></span>
            <span class="fileinput-filename"></span>

            <a href="#" class="close fileinput-exists" data-dismiss="fileinput" style="float: none">x</a>
        </div>
    </div>
</div>