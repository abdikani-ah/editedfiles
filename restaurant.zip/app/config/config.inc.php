<?php
if (!defined("PJ_HOST")) define("PJ_HOST", "localhost");
if (!defined("PJ_USER")) define("PJ_USER", "root");
if (!defined("PJ_PASS")) define("PJ_PASS", "");
if (!defined("PJ_DB")) define("PJ_DB", "fooddelivery");
if (!defined("PJ_PREFIX")) define("PJ_PREFIX", "script_");
if (!defined("PJ_INSTALL_FOLDER")) define("PJ_INSTALL_FOLDER", "/restaurant/");
if (!defined("PJ_INSTALL_PATH")) define("PJ_INSTALL_PATH", "/opt/lampp/htdocs/restaurant/");
if (!defined("PJ_INSTALL_URL")) define("PJ_INSTALL_URL", "http://localhost/restaurant/");
if (!defined("PJ_SALT")) define("PJ_SALT", "TI26L980");
if (!defined("PJ_INSTALLATION")) define("PJ_INSTALLATION", "MTI3NDQzNTMzNTQxNjMzNzAxMTcwNDQ3MzYyNzI0NTI3NzkxMDI3MzA1Mzg0MTEwMTczNDQ3MjY0MTUwMDE0NzkyNTI5MDk0MzE3OTUxNjQ1NTc3NTQzMjI4MDkxNzEwMjM1MCAxMTg1ODcxMzkwOTY0MzE4Njk2MTgyMjE3NDM0OTIzODg3MjE4MTY1NjA2Njk3ODA1MzM0MjY4NzUyMzQ4MTIwODk0MzAyNjI5NzMwNDkyMjA1MTY1MTMzMTI1Njk1NzUzMDM2IDk0MjY4NDAyMTM2MDE4ODM0NTk4MzU1NDMyNzg1NjIzMjQ5MTM1MDU0ODY4NTczMzk4ODg2MDIyMjc2OTAwNDQ1OTAwMTMwMTY2MzAwMTUyNDcyMDEwMDMwNDMzNzgxMTcyNw==");
?>