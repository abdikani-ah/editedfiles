<div class="modal-body"><?php echo $tpl['terms_conditions']; ?></div>
<div class="modal-footer">
	<button type="button" class="btn btn-default" data-dismiss="modal"><?php __('front_close');?></button>
</div>